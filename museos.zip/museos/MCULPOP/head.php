<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="Sitio web del Museo Nacional Culturas Populares">
    <meta name="keywords" content="Culturas, Polular, Populares, Museo Nacional Culturas Populares">
    <meta name="author" content="Mir Marin">
       
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Museo Nacional de las Culturas Populares - Pieza</title>
    
<script src="https://use.fontawesome.com/c8467a7612.js"></script>
<script type="text/javascript" src="js/jquery-3.2.1.js"></script>


    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/neutra-font.css">
    <link type="text/css" rel="stylesheet" href="css/materialize.css">
    
    <link type="text/css" rel="stylesheet" href="css/slick.css">
    <link type="text/css" rel="stylesheet" href="css/slick-theme_.css">    
    
    <link type="text/css" rel="stylesheet" href="css/styles.css">
    


</head>