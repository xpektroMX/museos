(function($){
  $(function(){
        $('.button-collapse').sideNav();
        $('.carousel.all').carousel({dist: 0, indicators: true}); //quiza borrar
        $('.carousel.carousel-slider#sliderHome').carousel({fullWidth: true});
  }); // end of document ready
})(jQuery); // end of jQuery name space



