<title>Museo del Nacional del virreinato</title>
<!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Importa materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
      <!--Importa Estilo Virreinato particular.css-->
      <link rel="stylesheet" type="text/css" href="css/estilo_virreinato.css">
      <link rel="stylesheet" type="text/css" href="css/fuentes_virreinato.css">

      <!--sitio optimizado para móviles-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <meta charset="utf-8">