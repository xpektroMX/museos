<!DOCTYPE html>
<html>
<!-- HEAD !-->
<?php include('head.php'); ?>
<body>

<!-- MENU !-->
<?php include('menu.php'); ?>

<!-- SLIDER !-->
	<div class="seccion-slider">
		<div id="slider-header" style="width: 1800px; height: 900px;">
			<div class="ls-slide" data-ls="duration: 3000;">
		        <img src="img/slide-1.jpg" class="ls-bg" >	        
			</div>	 
			<div class="ls-slide" data-ls="duration: 3000;">
		        <img src="img/slide-1.jpg" class="ls-bg" >	        
			</div>	 
			<div class="ls-slide" data-ls="duration: 3000;">
		        <img src="img/slide-1.jpg" class="ls-bg" >	        
			</div>	 
		</div>
	</div>


<!-- FOOTER !-->
<?php include('footer.php'); ?>

<script type="text/javascript">
	

</script>


</body>
</html>

















