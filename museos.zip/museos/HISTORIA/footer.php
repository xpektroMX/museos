<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>

<div class="seccion-footer">
<div class="container row">
	<div class="col l6 s12 izquierda">
		<a href="#">Directorio</a>
		<a href="#">Términos y condiciones</a>
		<a href="#">Mapa de sitio</a>
		<a href="#">Política de privacidad</a>
	</div>
	<div class="col l6 s12 derecha">
		Secretaria de Cultura-INAH. Todos los derechos reservados.
	</div>
</div>
</div>