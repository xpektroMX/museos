<head>
	<title>Museo Nacional de Historia</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="DESCRIPCION POR LLENAR" />
	<meta name="keywords" content="KEYWORDS POR LLENAR" />
	<meta name="author" content="Vannelo" />
	<meta name="copyright" content="SIN LLENAR" />
	<link rel="icon" type="image/png" href="img/icon.png">
	<link rel="stylesheet" href="css/materialize.css">
	<link rel="stylesheet" href="css/estilo.css">


	<!-- LAYERSLIDER !-->
	<link rel="stylesheet" href="layerslider/css/layerslider.css" type="text/css">
	<script src="layerslider/js/jquery.js" type="text/javascript"></script>
	<script src="layerslider/js/greensock.js" type="text/javascript"></script>
	<script src="layerslider/js/layerslider.transitions.js" type="text/javascript"></script>
	<script src="layerslider/js/layerslider.kreaturamedia.jquery.js" type="text/javascript"></script>
	

	<!-- META SOCIAL !-->
	<meta property="og:type"	content="website" />
	<meta property="og:site_name" content="Museo Nacional de San Carlos"/>
	<meta property="og:description" content="SIN LLENAR" />
	<meta property="og:url" content="SIN LLENAR" />
	<meta property="og:image" content="SIN LLENAR" />
	<meta property="og:title" content="Museo Nacional de San Carlos" />

</head>