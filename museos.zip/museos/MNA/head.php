<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="description" content="Sitio web del Museo Nacional de Antropología">
    <meta name="keywords" content="Museo Nacional de Antropología, MNA, México">
    <meta name="author" content="Susana Zavala">

      <!--Import Google Icon Font-->
      <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
      <!--Import materialize.css-->
      <link type="text/css" rel="stylesheet" href="css/materialize.min.css"  media="screen,projection"/>
      
	<link rel="stylesheet" href="css/tema.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	
      <!--Let browser know website is optimized for mobile-->
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
      <title>Museo Nacional de Antropología</title>
    </head>