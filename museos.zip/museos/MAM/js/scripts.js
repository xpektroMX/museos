/*!
 * MUSEO DE ARTE MODERNO
 * Version - 1.0
 * Author: Vannelo - http://www.codein.mx

 * - RESOURCES -
 * COLORS
 * ACCENT: #118185;
 * ACCENT: #;

*/

	// MENU 
		$('.boton-menu').click(function() {
			$('.contenedor-mobile').slideToggle();
		});
