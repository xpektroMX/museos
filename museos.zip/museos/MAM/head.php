<head>
	<title>Museo de Arte Moderno</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="DESCRIPCION POR LLENAR" />
	<meta name="keywords" content="KEYWORDS POR LLENAR" />
	<meta name="author" content="Vannelo - http://www.codein.mx" />
	<meta name="copyright" content="Vannelo - http://www.codein.mx" />
	<link rel="icon" type="image/jpg" href="img/icon.jpg">
	<link rel="stylesheet" href="css/materialize.css">
	<link rel="stylesheet" href="css/estilo.css">

	<script type="text/javascript" src="js/jquery.js"></script>


	<!-- META SOCIAL !-->
	<meta property="og:type"	content="website" />
	<meta property="og:site_name" content="Museo de Arte Moderno"/>
	<meta property="og:description" content="SIN LLENAR" />
	<meta property="og:url" content="SIN LLENAR" />
	<meta property="og:image" content="SIN LLENAR" />
	<meta property="og:title" content="Museo de Arte Moderno" />

</head>