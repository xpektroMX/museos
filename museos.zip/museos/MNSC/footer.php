<div class="seccion-footer">
	<div class="container row">
		<div class="col l6 s12 izquierda">
			<a href="#">Política de Privacidad</a>
			<a href="#">Mapa de Sitio</a>
		</div>
		<div class="col l6 s12 derecha">
			Secretaría de Cultura 2017. Todos los derechos reservados
		</div>
	</div>
	</div>

<script type="text/javascript" src="js/materialize.js"></script>
<script type="text/javascript" src="js/scripts.js"></script>