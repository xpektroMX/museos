/*!
 * MUSEO DE SAN CARLOS WEBSITE
 * Version - 1.0
 * Author: Vannelo

 * - RESOURCES -
 * COLORS
 * ACCENT: #e8e8e8;
 * ACCENT: #4d4d4d;

*/

// MENU TOGGLE 
	$('.abrir-menu').click(function() {
		$('.menu-escondido').slideToggle('slow');
	});
